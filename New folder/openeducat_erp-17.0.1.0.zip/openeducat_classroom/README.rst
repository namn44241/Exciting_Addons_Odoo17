This module adds classroom management feature to OpenEduCat_Core.
