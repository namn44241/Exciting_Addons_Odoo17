This module provide feature of web.
